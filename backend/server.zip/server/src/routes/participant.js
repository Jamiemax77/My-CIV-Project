const express = require('express');
const { pool } = require('../db');
const { makeId } = require('../lib/id');
const { ApiError, asyncHandler } = require('../lib/errors');
const {
  reimbursementToPublic,
  reportToPublic,
  accountToPublic,
  transferProofToPublic,
} = require('../lib/serialize');
const { requireAuth, requireRole } = require('../middleware/auth');

const router = express.Router();
router.use(requireAuth, requireRole('participant'));

router.get(
  '/dashboard',
  asyncHandler(async (req, res) => {
    const participantId = req.session.profileId;

    const [disbursements] = await pool.query(
      "SELECT * FROM disbursements WHERE participant_id = ? AND status != 'draft'",
      [participantId]
    );
    const [reimbursements] = await pool.query(
      'SELECT amount, status FROM reimbursements WHERE participant_id = ?',
      [participantId]
    );
    const [transferProofs] = await pool.query(
      'SELECT id, disbursement_id FROM transfer_proofs WHERE participant_id = ?',
      [participantId]
    );

    const total = disbursements.reduce((sum, d) => sum + Number(d.amount), 0);
    const used = reimbursements
      .filter((r) => r.status === 'approved')
      .reduce((sum, r) => sum + Number(r.amount), 0);

    res.json({
      ok: true,
      data: {
        total,
        used,
        remaining: total - used,
        approvedCount: reimbursements.filter((r) => r.status === 'approved').length,
        pendingCount: reimbursements.filter((r) => r.status === 'pending').length,
        disbursements: disbursements.map((d) => {
          const proof = transferProofs.find((t) => t.disbursement_id === d.id);
          return {
            id: d.id,
            title: d.title,
            amount: Number(d.amount),
            disbursedAt: d.disbursed_at,
            transferProofId: proof ? proof.id : null,
          };
        }),
      },
    });
  })
);

router.get(
  '/reimbursements',
  asyncHandler(async (req, res) => {
    const [rows] = await pool.query(
      'SELECT * FROM reimbursements WHERE participant_id = ? ORDER BY created_at DESC',
      [req.session.profileId]
    );
    res.json({ ok: true, data: rows.map(reimbursementToPublic) });
  })
);

router.post(
  '/reimbursements',
  asyncHandler(async (req, res) => {
    const { type, category, amount, description, proofFileId, proofFileName } = req.body;
    if (!type || !category || !(amount > 0) || !description) {
      throw new ApiError('Data pengajuan tidak lengkap.');
    }
    const id = makeId('r');
    await pool.query(
      `INSERT INTO reimbursements
        (id, participant_id, type, category, amount, description, proof_path, proof_name, status)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending')`,
      [id, req.session.profileId, type, category, amount, description, proofFileId || null, proofFileName || null]
    );
    res.status(201).json({ ok: true, data: { id } });
  })
);

router.get(
  '/reports',
  asyncHandler(async (req, res) => {
    const [rows] = await pool.query(
      'SELECT * FROM reports WHERE participant_id = ? ORDER BY created_at DESC',
      [req.session.profileId]
    );
    res.json({ ok: true, data: rows.map(reportToPublic) });
  })
);

router.post(
  '/reports',
  asyncHandler(async (req, res) => {
    const { semester, gpa, fileId, fileName } = req.body;
    if (!semester || !(gpa > 0 && gpa <= 4)) throw new ApiError('Data laporan tidak lengkap.');
    const id = makeId('rep');
    await pool.query(
      `INSERT INTO reports (id, participant_id, semester, gpa, file_path, file_name, status)
       VALUES (?, ?, ?, ?, ?, ?, 'pending')`,
      [id, req.session.profileId, semester, gpa, fileId || null, fileName || null]
    );
    res.status(201).json({ ok: true, data: { id } });
  })
);

router.get(
  '/accounts',
  asyncHandler(async (req, res) => {
    const [rows] = await pool.query('SELECT * FROM accounts WHERE participant_id = ?', [
      req.session.profileId,
    ]);
    res.json({ ok: true, data: rows.map(accountToPublic) });
  })
);

router.post(
  '/accounts',
  asyncHandler(async (req, res) => {
    const { kind, provider, number, holderName } = req.body;
    if (!kind || !provider || !number || !holderName) throw new ApiError('Data rekening tidak lengkap.');

    const [existing] = await pool.query(
      'SELECT COUNT(*) as count FROM accounts WHERE participant_id = ?',
      [req.session.profileId]
    );
    const id = makeId('acc');
    await pool.query(
      `INSERT INTO accounts (id, participant_id, kind, provider, number, holder_name, is_primary)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [id, req.session.profileId, kind, provider, number, holderName, existing[0].count === 0]
    );
    res.status(201).json({ ok: true, data: { id } });
  })
);

router.get(
  '/transfer-proofs',
  asyncHandler(async (req, res) => {
    const [rows] = await pool.query('SELECT * FROM transfer_proofs WHERE participant_id = ?', [
      req.session.profileId,
    ]);
    res.json({ ok: true, data: rows.map(transferProofToPublic) });
  })
);

router.post(
  '/transfer-proofs/:id/confirm',
  asyncHandler(async (req, res) => {
    const [rows] = await pool.query('SELECT * FROM transfer_proofs WHERE id = ? LIMIT 1', [req.params.id]);
    const proof = rows[0];
    if (!proof) throw new ApiError('Data tidak ditemukan.', 404);
    if (proof.participant_id !== req.session.profileId) {
      throw new ApiError('Tidak memiliki akses untuk data ini.', 403);
    }
    await pool.query('UPDATE transfer_proofs SET confirmed_by_participant = TRUE WHERE id = ?', [req.params.id]);
    res.json({ ok: true, data: { ok: true } });
  })
);

module.exports = router;
