const express = require('express');
const { pool } = require('../db');
const { makeId } = require('../lib/id');
const { ApiError, asyncHandler } = require('../lib/errors');
const { profileToPublic, reimbursementToPublic, reportToPublic } = require('../lib/serialize');
const { requireAuth, requireRole } = require('../middleware/auth');

const router = express.Router();
router.use(requireAuth, requireRole('admin'));

router.get(
  '/participants',
  asyncHandler(async (req, res) => {
    const [profiles] = await pool.query("SELECT * FROM profiles WHERE role = 'participant'");
    const [disbursements] = await pool.query("SELECT * FROM disbursements WHERE status != 'draft'");
    const [reimbursements] = await pool.query(
      "SELECT participant_id, amount FROM reimbursements WHERE status = 'approved'"
    );
    const [reports] = await pool.query('SELECT DISTINCT participant_id FROM reports');
    const reportedIds = new Set(reports.map((r) => r.participant_id));

    const data = profiles.map((profile) => {
      const total = disbursements
        .filter((d) => d.participant_id === profile.id)
        .reduce((sum, d) => sum + Number(d.amount), 0);
      const used = reimbursements
        .filter((r) => r.participant_id === profile.id)
        .reduce((sum, r) => sum + Number(r.amount), 0);
      return {
        profile: profileToPublic(profile),
        remaining: total - used,
        status: reportedIds.has(profile.id) ? 'aktif' : 'belum_lapor',
      };
    });

    res.json({ ok: true, data });
  })
);

router.post(
  '/disbursements',
  asyncHandler(async (req, res) => {
    const { participantId, title, amount, period, disbursedAt, note, status } = req.body;
    if (!participantId || !title || !(amount > 0)) throw new ApiError('Data pencairan tidak lengkap.');
    const id = makeId('d');
    await pool.query(
      `INSERT INTO disbursements (id, participant_id, title, amount, period, disbursed_at, note, status)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [id, participantId, title, amount, period || null, disbursedAt || new Date(), note || null, status || 'disbursed']
    );
    res.status(201).json({ ok: true, data: { id } });
  })
);

router.get(
  '/reimbursements',
  asyncHandler(async (req, res) => {
    const [rows] = await pool.query('SELECT * FROM reimbursements ORDER BY created_at DESC');
    res.json({ ok: true, data: rows.map(reimbursementToPublic) });
  })
);

router.post(
  '/reimbursements/:id/review',
  asyncHandler(async (req, res) => {
    const { status } = req.body;
    if (status !== 'approved' && status !== 'rejected') throw new ApiError('Status tidak valid.');
    const [result] = await pool.query(
      'UPDATE reimbursements SET status = ?, reviewed_by = ?, reviewed_at = NOW() WHERE id = ?',
      [status, req.session.profileId, req.params.id]
    );
    if (result.affectedRows === 0) throw new ApiError('Data tidak ditemukan.', 404);
    res.json({ ok: true, data: { ok: true } });
  })
);

router.get(
  '/reports',
  asyncHandler(async (req, res) => {
    const [rows] = await pool.query('SELECT * FROM reports ORDER BY created_at DESC');
    res.json({ ok: true, data: rows.map(reportToPublic) });
  })
);

router.post(
  '/reports/:id/review',
  asyncHandler(async (req, res) => {
    const { status } = req.body;
    if (status !== 'verified' && status !== 'revision') throw new ApiError('Status tidak valid.');
    const [result] = await pool.query(
      'UPDATE reports SET status = ?, reviewed_by = ?, reviewed_at = NOW() WHERE id = ?',
      [status, req.session.profileId, req.params.id]
    );
    if (result.affectedRows === 0) throw new ApiError('Data tidak ditemukan.', 404);
    res.json({ ok: true, data: { ok: true } });
  })
);

router.post(
  '/transfer-proofs',
  asyncHandler(async (req, res) => {
    const {
      participantId,
      disbursementId,
      amount,
      senderBank,
      destAccount,
      transferredAt,
      referenceNo,
      proofFileId,
      proofFileName,
    } = req.body;
    if (!participantId || !disbursementId || !(amount > 0) || !senderBank || !destAccount || !referenceNo) {
      throw new ApiError('Data bukti transfer tidak lengkap.');
    }
    const id = makeId('tp');
    await pool.query(
      `INSERT INTO transfer_proofs
        (id, participant_id, disbursement_id, amount, sender_bank, dest_account, transferred_at, reference_no, proof_path, proof_name)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        id,
        participantId,
        disbursementId,
        amount,
        senderBank,
        destAccount,
        transferredAt || new Date(),
        referenceNo,
        proofFileId || null,
        proofFileName || null,
      ]
    );
    res.status(201).json({ ok: true, data: { id } });
  })
);

module.exports = router;
